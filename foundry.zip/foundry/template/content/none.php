<?php
/**
 * Template part for none content found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Foundry
 * @since Foundry 1.0
 */

?>

<div class="wrapper py-48 text-center">
	<h1 class="title text-primary-600">The is not the page you are looking for</h1>
</div>

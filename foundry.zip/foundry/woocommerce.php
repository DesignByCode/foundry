<?php
/**
 * Foundry woocommerce support page
 *
 * @package WordPress
 * @subpackage Foundry
 * @since Foundry 1.0
 */
get_header(); ?>

<div class="wrapper">
	<?php woocommerce_content(); ?>
</div>


get_footer();
